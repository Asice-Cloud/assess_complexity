"""assess_complexity package"""

from .analyzer import analyze_file

__all__ = ["analyze_file"]
